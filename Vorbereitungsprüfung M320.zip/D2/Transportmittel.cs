﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prüfungsvorbeitung_D2
{
    public abstract class Transportmittel
    {
        public abstract double BerechneKosten(int kilometer);
    }
}
